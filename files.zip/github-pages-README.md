# ☀️ Merch Ops — Daily Update

Interactive mobile-app-style daily update for the Merch Ops Execution team.  
Built to be hosted on **GitHub Pages** — just like the [PPM Weekly Scorecard](https://willschleichert.github.io/ppm-weekly-scorecard/).

---

## 🚀 Deploy to GitHub Pages (5 minutes)

### Option A: Quick — Upload via GitHub UI

1. Go to [github.com/new](https://github.com/new) and create a new repo  
   - Name it something like `merch-ops-daily-update`  
   - Set it to **Public** (required for free GitHub Pages)  
   - Click **Create repository**

2. On the repo page, click **"uploading an existing file"**  
   - Drag and drop the `index.html` file  
   - Click **Commit changes**

3. Go to **Settings → Pages**  
   - Under "Source", select **Deploy from a branch**  
   - Branch: `main`, folder: `/ (root)`  
   - Click **Save**

4. Wait ~60 seconds, then visit:  
   `https://YOUR-USERNAME.github.io/merch-ops-daily-update/`

### Option B: Git command line

```bash
git init
git add .
git commit -m "Initial commit — daily update app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/merch-ops-daily-update.git
git push -u origin main
```

Then enable Pages in Settings → Pages → main branch → Save.

---

## 📱 How it works

- **Desktop**: Shows a phone mockup frame on a dark background (matches the PPM scorecard style)
- **Mobile**: Goes full-bleed — feels like a native app
- **5 tabs**: Today, Actions, Team, Alerts, Wins
- **Tap any item** to see full details in a slide-up sheet
- **Live clock** in the status bar
- **Zero dependencies to install** — just a single HTML file with React loaded from CDN

---

## 🔄 Updating the data

All the data lives at the top of the `<script>` block in `index.html`:

- `CALENDAR` — today's meetings
- `ACTIONS` — open items needing attention
- `TEAM` — team member focus areas
- `ALERTS` — upcoming watch-outs
- `WINS` — positive callouts for the wider team

Edit those arrays, commit, and the site updates automatically.

---

## 📁 Structure

```
merch-ops-daily-update/
├── index.html    ← The entire app (single file, self-contained)
└── README.md     ← This file
```

---

Built by Merch Ops · Powered by Claude
